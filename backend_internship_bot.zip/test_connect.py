# test_connect.py
import os
import logging
from dotenv import load_dotenv
from binance import Client
from binance.exceptions import BinanceAPIException, BinanceRequestException

# ---------- logging ----------
logging.basicConfig(
    filename="test_connect.log",
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)
logger = logging.getLogger(__name__)

# ---------- load env ----------
load_dotenv()
API_KEY = os.getenv("API_KEY")
API_SECRET = os.getenv("API_SECRET")

if not API_KEY or not API_SECRET:
    logger.error("API_KEY or API_SECRET is missing in .env")
    raise SystemExit("Please set API_KEY and API_SECRET in .env")

# ---------- init Spot Testnet client ----------
client = Client(API_KEY, API_SECRET)
client.API_URL = "https://testnet.binance.vision/api"

def main():
    # 1) Test connection / account
    try:
        info = client.get_account()
        logger.info("Fetched account info successfully")
        print("✅ Spot Testnet account info fetched!")
    except BinanceAPIException as e:
        logger.error(f"BinanceAPIException: {e}")
        print("❌ BinanceAPIException:", e)
        return
    except BinanceRequestException as e:
        logger.error(f"BinanceRequestException: {e}")
        print("❌ BinanceRequestException:", e)
        return
    except Exception as e:
        logger.exception("Unexpected error fetching account info")
        print("❌ Error:", e)
        return

    # 2) Validate a test market order (no execution)
    SYMBOL = "BTCUSDT"
    SIDE = "BUY"
    QTY = 0.0005

    try:
        client.create_test_order(
            symbol=SYMBOL,
            side=SIDE,
            type='MARKET',
            quantity=QTY
        )
        logger.info(f"Test order validated for {SYMBOL} {SIDE} {QTY}")
        print("✅ Test order validated (no execution) — check test_connect.log for details.")
    except BinanceAPIException as e:
        logger.error(f"Order API error: {e}")
        print("❌ Order API error:", e)
    except Exception as e:
        logger.exception("Unexpected error creating test order")
        print("❌ Error:", e)

if __name__ == "__main__":
    main()
